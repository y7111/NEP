package com.nep.entity;

import java.io.Serializable;

/**
 * @author ljyl
 * 管理员信息
 */
public class Admin extends Operator implements Serializable{
    private static final long serialVersionUID = 1L;


}
