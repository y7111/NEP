package com.nep.service;

public interface AdminService {
    /**
     * 管理员登录
     */
    public boolean login(String loginCode,String password);

}
