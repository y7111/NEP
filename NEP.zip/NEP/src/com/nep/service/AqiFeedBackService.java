package com.nep.service;

import com.nep.entity.AqiFeedback;

public interface AqiFeedBackService {
    public void saveFeedBack(AqiFeedback afb);
}
