package com.nep.entity;

import java.io.Serializable;

/**
 * @author Yanghq
 * 管理员信息
 */
public class Admin implements Serializable {
    private static final long serialVersionUID = 1L;
}
