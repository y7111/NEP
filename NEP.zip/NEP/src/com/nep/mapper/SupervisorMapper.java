package com.nep.mapper;

import java.io.FileInputStream;
import java.util.Properties;

public class SupervisorMapper {
    Properties prop =  new Properties();
    prop.load(new FileInputStream("NEP"))
}
